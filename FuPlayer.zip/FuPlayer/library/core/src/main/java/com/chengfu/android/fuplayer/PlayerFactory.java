package com.chengfu.android.fuplayer;

import androidx.annotation.NonNull;

public interface PlayerFactory {

    @NonNull
    FuPlayer create();
}
