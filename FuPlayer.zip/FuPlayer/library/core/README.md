# FuPlayer core library module #

The core of the FuPlayer library.
