# FuPlayer
An extensible media player for Android
